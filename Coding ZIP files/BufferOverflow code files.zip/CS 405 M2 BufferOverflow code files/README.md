How to run:

1. `g++ -std=c++11 -o ./buov ./BufferOverflow.cpp`
2. `./buov`
3. Profit
