How to run:

1. `g++ -std=c++11 -o ./numo ./NumericOverflows.cpp`
2. `./numo`
3. Profit
