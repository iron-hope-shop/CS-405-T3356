How to run:

1. `g++ -std=c++11 -o ./sqli ./SQLInjection.cpp`
2. `./sqli`
3. Profit
